--Full Backup
BACKUP DATABASE [Chinook] 
TO  DISK = N'G:\SQLBackups\Chinook_fullbk_20190424.bak' 
WITH NOFORMAT, NOINIT,  NAME = N'Chinook-Full Database Backup'
, SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  STATS = 10
GO
---Differential
BACKUP DATABASE [Chinook] 
TO  DISK = N'G:\SQLBackups\Chinook_20190424.bak' 
WITH  DIFFERENTIAL
 , NOFORMAT, NOINIT,  NAME = N'Chinook-Full Database Backup', 
 SKIP, NOREWIND, NOUNLOAD
 ,  STATS = 10
GO
--Backup Log
BACKUP LOG [Chinook] 
TO  DISK = N'G:\SQLBackups\Chinook_Tlogbk_20190424.bak' 
WITH NOFORMAT, NOINIT,  NAME = N'Chinook-Full Database Backup'
, SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  STATS = 10
GO

--1:12 un solo archivo sin parametros
--2:25 un solo archivo + solo parametros
--1:09 multiples archivos + parametros
BACKUP DATABASE [StackOverflow2010] 
TO  DISK = N'G:\SQLBackups\StackOverFlow2010_20190424_t001.bak'
,DISK = N'G:\SQLBackups\StackOverFlow2010_20190424_t002.bak'
,DISK = N'G:\SQLBackups\StackOverFlow2010_20190424_t003.bak'
,DISK = N'G:\SQLBackups\StackOverFlow2010_20190424_t004.bak'
WITH NOFORMAT, NOINIT,  NAME = N'StackOverflow2010-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 5
,MAXTRANSFERSIZE = 2097152, BUFFERCOUNT = 50, BLOCKSIZE = 4096
GO



