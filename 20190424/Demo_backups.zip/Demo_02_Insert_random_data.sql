Use Chinook
with randowvalues
    as(
 --10.8 is the difference between 105.8 minus 95
 
       select 1 id,CAST(RAND(CHECKSUM(NEWID()))*10.8 as real) +95 as randomnumber
	    union  all
        select id + 1,CAST(RAND(CHECKSUM(NEWID()))*10.8 as real)  +95 as randomnumber
        from randowvalues
        where 
          id < 10000000
      )
    insert into random_values
	select id, randomnumber
    from randowvalues
    OPTION(MAXRECURSION 0)
	/*
	--drop table random_values
	create table random_values (
	id bigint,
	randomnumber float)*/
	select count(*) from random_values