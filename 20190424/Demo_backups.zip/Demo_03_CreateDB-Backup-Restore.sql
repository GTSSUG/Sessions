/*
Crear una base de datos 
Agregar Filegroups
Insertar Datos
Tomar un backup
Simular una falla
Tratar de restaura con los backups y el taillog
*/
use master
--Creamos Base de datos
CREATE DATABASE FGDB;
GO
-- Agregamos un segundo Filegroup
ALTER DATABASE FGDB
ADD FILEGROUP SecondaryFGDB;
GO
 --- Agregamos un Datafile al nuevo filegroup
ALTER DATABASE FGDB
ADD FILE
(
    NAME = FGDBarchiveData,
    FILENAME = 'G:\SQLData\FGDB_archiveData.ndf',
    SIZE = 5MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10MB
)
TO FILEGROUP SecondaryFGDB;
-- Validamos cuales son los filegroups y donde se ubican fisicamente
use fgdb
SELECT DB_NAME() databasename,
sf.name FileName,
size/128 SizeMB,
fg.name FGName,sf.physical_name
FROM sys.database_files sf
INNER JOIN
sys.filegroups fg ON sf.data_space_id=fg.data_space_id

--Insertaremos datos, pero antes crearemos las tablas
CREATE TABLE EmpleadoActivo  (
    ID int IDENTITY(1,1) PRIMARY KEY,
    Nombre nvarchar(100) NOT NULL);
GO
 
CREATE TABLE EmpleadoInactivo (
    ID int IDENTITY(1,1) PRIMARY KEY,
    Nombre nvarchar(100) NOT NULL)
ON SecondaryFGDB;
GO

INSERT INTO EmpleadoActivo (Nombre)
values('Active1'),('Active2'),('Active3'),('Active4'),('Active5')
 
GO
INSERT INTO InactiveAuthor (Nombre)
values('Inactive1'),('Inactive2'),('Inactive3'),('Inactive4'),('Inactive5')
--- Validamos donde fueron creadas las tablas
SELECT 
	OBJECT_NAME(st.object_id) AS ObjectName, 
	sds.name AS FileGroup
    FROM sys.data_spaces sds
        JOIN sys.indexes si on si.data_space_id = sds.data_space_id
        JOIN sys.tables st  on st.object_id = si.object_id
    WHERE si.index_id < 2
        AND st.type = 'U';
--Backup a la DB 
Backup Database [FGDB]
to Disk = 'G:\SQLBackups\FGDB_20190424_1900.bak'
with format -- sobreescribe cualquier backup existente
,stats = 10
--insertamos datos en el FG Secundario
INSERT INTO EmpleadoInactivo (Nombre)
values('Inactive6'),
('Inactive7'),
('Inactive8'),
('Inactive9'),
('Inactive10')
--> Backup al SFG
BACKUP DATABASE [FGDB]
   FILEGROUP = 'SecondaryFGDB'
   TO DISK = 'G:\SQLBackups\FGDB_SecundaryFG_20190424_1900.bak'
GO
--Simularemos una falla de Hardware
USE MASTER;
GO
ALTER DATABASE FGDB SET OFFLINE WITH ROLLBACK IMMEDIATE
---Borraremos el SFG del Filesystem
---FILENAME = 'G:\SQLData\FGDB_archiveData.ndf'

--- Se reinicia el motor de la base de datos
USE MASTER;
GO
ALTER DATABASE FGDB SET ONLINE

exec xp_readerrorlog 0,1 --leermos el log de sql server
/* la base datos fallo!!! */
USE MASTER
GO
-- Necesitamos obtener un tail log backup
-- de las ultimas transacciones registradas en el tlog file
BACKUP LOG FGDB
   TO DISK = 'G:\SQLBackups\FGDBTaillog_20190424_1900.bak'
   WITH NO_TRUNCATE;
GO
---Restauramos el Filegroup que se perdio con la falla de hardware
RESTORE DATABASE FGDB
   FILE = 'FGDBarchiveData',
   FILEGROUP = 'SecondaryFGDB'
   FROM DISK = 'G:\SQLBackups\FGDB_SecundaryFG_20190424_1900.bak'
   WITH NORECOVERY --- Dejamos en modo de restauracion la base de datos 
GO

--Porque?  es necesario restaurar el Tail log backup

RESTORE LOG FGDB
   FROM DISK = 'G:\SQLBackups\FGDBTaillog_20190424_1900.bak'
   WITH RECOVERY --Podemos la base de datos en modo online

use FGDB
select * from EmpleadoActivo
select * from EmpleadoInactivo