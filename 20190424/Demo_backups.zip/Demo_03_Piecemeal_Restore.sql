---Piecemeal restore
/*
Conlleva un serie de pasos en secuencia, iniciando con un filegroup primario 
y 1 o mas secundarios en modo READONLY
*/
--Agregamos un nuevo FG
ALTER DATABASE FGDB
ADD FILEGROUP ReadOnlyFGDB;
GO
 ----Agregamos un Datafile a la base de datos en el nuevo filegroup
ALTER DATABASE FGDB
ADD FILE
(
    NAME = FGdBreadonlyData,
    FILENAME = 'F:\SQLData\FGDBreadonlydata.ndf',
    SIZE = 5MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 10MB
)
TO FILEGROUP ReadOnlyFGDB;
GO
--Creamos un tabla en el nuevo Filegroup
CREATE TABLE ReporteEmpleado (
    ID int IDENTITY(1,1) PRIMARY KEY,
    Nombre nvarchar(100) NOT NULL)
ON ReadOnlyFGDB;
GO
 --insertamos datos
INSERT INTO ReporteEmpleado (Nombre)
values('Report1'),
('Report2'),
('Report3'),
('Report4'),
('Report5')

select * from ReporteEmpleado

---Modificamos el FG a READONLY
use master
GO
ALTER DATABASE FGDB MODIFY FILEGROUP ReadOnlyFGDB READ_ONLY;

--tomamos un backup de la DB
BACKUP DATABASE FGDB
    TO DISK = 'G:\SQLBackups\FGDB_20190424_1900.bak'
    WITH FORMAT;
GO

--Validacion de los FG existentes
use FGDB
SELECT DB_NAME() databasename,
sf.name FileName,
size/128 SizeMB,
fg.name FGName,sf.physical_name,
sf.state_desc,
sf.is_read_only 
FROM sys.database_files sf
INNER JOIN
sys.filegroups fg
ON sf.data_space_id=fg.data_space_id
---tomamos un backup de FG Secundario
BACKUP DATABASE FGDB
   FILEGROUP = 'ReadOnlyFGDB'
   TO DISK = 'G:\SQLBackups\FGDB_ReadonlyFG_20190424_1900.bak'
WITH FORMAT
GO
---Falla el Hardware y se pierde la base de datos
USE MASTER;
GO
DROP DATABASE FGDB
--Pero tenemos los backups
USE MASTER
GO
RESTORE DATABASE FGDB READ_WRITE_FILEGROUPS  ---Restauremos solo los FG R/W
FROM DISK = 'G:\SQLBackups\FGDB_20190424_1900.bak'  
WITH PARTIAL, RECOVERY   ---Restauraremos parcialmente
GO
SELECT TOP (1000) [ID]
      ,nombre
  FROM [FGDB].[dbo].[EmpleadoInactivo]
 
  GO
 
  SELECT TOP (1000) [ID]
      ,[Nombre]
             FROM [FGDB].[dbo].ReportEmpleado
---- Restauramos completamente la base de datos.
RESTORE DATABASE SQLShackFGDB
   FILE = 'readonlyData',
   FILEGROUP = 'ReadOnlySQLShackFGDB'
   FROM DISK = 'f:\PowerSQL\ReadOnlySQLShackFGDB.bak'
   WITH RECOVERY

   ---tenemos de nuevo nuestra informacion
   SELECT TOP (1000) [ID]
      ,[Nombre]
             FROM [FGDB].[dbo].ReportEmpleado