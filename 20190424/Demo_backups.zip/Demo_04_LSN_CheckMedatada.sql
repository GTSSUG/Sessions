select * from ::fn_dblog(default, default)
select * from sys.dm_db_log_stats(db_id('salesdb')); 

6	FULL	00000175:0000399e:0001	00000175:000039a5:0001

6	FULL	00000175:000039b4:0001	00000175:000039b9:0001


insert into Employees (FirstName,MiddleInitial,LastName)
select 'Fernando','','Alonso'

select * from [dbo].[Employees] where EmployeeID > 23