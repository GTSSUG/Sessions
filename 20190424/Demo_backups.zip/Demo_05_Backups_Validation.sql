RESTORE VERIFYONLY 
FROM DISK = 'F:\BackupCorrupto\Chinook.bak';
GO